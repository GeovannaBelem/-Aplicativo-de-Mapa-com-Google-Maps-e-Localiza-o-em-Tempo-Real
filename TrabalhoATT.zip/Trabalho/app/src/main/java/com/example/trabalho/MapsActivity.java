package com.example.trabalho;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;

import com.example.trabalho.databinding.ActivityMapsBinding;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.util.ArrayList;
import java.util.List;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private static final int REQUEST_LOCATION_UPDATES = 1;
    private GoogleMap mMap;
    private ActivityMapsBinding binding;

    private FusedLocationProviderClient fusedLocationProviderClient;
    private LocationRequest locationRequest;
    private LocationCallback locationCallback;

    private List<LatLng> caminhoPercorrido = new ArrayList<>();
    private Polyline polyline;

    private Circle circle; // Círculo de precisão

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        UiSettings mapUI = mMap.getUiSettings();
        mapUI.setAllGesturesEnabled(true);
        mapUI.setCompassEnabled(true);
        mapUI.setZoomControlsEnabled(true);

        SharedPreferences prefs = getSharedPreferences("configMapa", MODE_PRIVATE);
        int tipoMapa = prefs.getInt("tipoMapa", GoogleMap.MAP_TYPE_NORMAL);
        String navegacao = prefs.getString("navegacao", "north");
        String icone = prefs.getString("icone", "padrao");
        boolean trafego = prefs.getBoolean("trafego", false);

        float latitude = prefs.getFloat("latitude", -12.9777f);
        float longitude = prefs.getFloat("longitude", -38.5016f);
        LatLng posicao = new LatLng(latitude, longitude);

        mMap.setMapType(tipoMapa);
        mMap.setTrafficEnabled(trafego);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            mMap.setMyLocationEnabled(true);
        }

        if (icone.equals("padrao")) {
            mMap.addMarker(new MarkerOptions().position(posicao).title("Você está aqui"));
        } else {
            mMap.addMarker(new MarkerOptions()
                    .position(posicao)
                    .title("Você está aqui")
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.localizacao)));
        }

        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(posicao, 15));

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        locationRequest = LocationRequest.create();
        locationRequest.setInterval(3000);
        locationRequest.setPriority(Priority.PRIORITY_HIGH_ACCURACY);

        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null) return;

                Location location = locationResult.getLastLocation();
                if (location != null) {
                    LatLng novaPosicao = new LatLng(location.getLatitude(), location.getLongitude());

                    // Adiciona/atualiza o círculo de precisão
                    if (circle == null) {
                        circle = mMap.addCircle(new CircleOptions()
                                .center(novaPosicao)
                                .radius(location.getAccuracy()) // precisão em metros
                                .strokeColor(Color.parseColor("#800080")) // borda roxa
                                .fillColor(0x88AA00FF)
                                .strokeWidth(4));
                    } else {
                        circle.setCenter(novaPosicao);
                        circle.setRadius(location.getAccuracy());
                    }

                    if (navegacao.equals("course")) {
                        mMap.animateCamera(CameraUpdateFactory.newCameraPosition(
                                new CameraPosition.Builder()
                                        .target(novaPosicao)
                                        .zoom(17)
                                        .bearing(location.getBearing())
                                        .tilt(45)
                                        .build()
                        ));

                        caminhoPercorrido.add(novaPosicao);

                        if (polyline == null) {
                            polyline = mMap.addPolyline(new PolylineOptions()
                                    .addAll(caminhoPercorrido)
                                    .width(10)
                                    .color(Color.BLUE));
                        } else {
                            polyline.setPoints(caminhoPercorrido);
                        }

                    } else {
                        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(novaPosicao, 15));
                    }
                }
            }
        };

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            fusedLocationProviderClient.requestLocationUpdates(locationRequest, locationCallback, null);
        }

        if (navegacao.equals("course")) {
            mMap.getUiSettings().setRotateGesturesEnabled(true);
        }
    }
}
