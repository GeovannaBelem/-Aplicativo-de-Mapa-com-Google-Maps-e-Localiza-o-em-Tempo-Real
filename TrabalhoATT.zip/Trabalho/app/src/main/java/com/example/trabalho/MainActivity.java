package com.example.trabalho;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.GoogleMap;

public class MainActivity extends AppCompatActivity {

    // Componentes da interface
    RadioButton radioVetorial, radioSatelite, radioHibrido;
    RadioButton radioNorthUp, radioCourseUp, radioNenhuma;
    RadioButton radioPadrao, radioPersonalizado;
    Switch switchTrafego;
    Button btnVisualizarMapa;

    // Localização
    private static final int REQUEST_LOCATION_UPDATES = 1;
    private FusedLocationProviderClient fusedLocationProviderClient;
    private LocationRequest locationRequest;
    private LocationCallback locationCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar localização
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        locationRequest = LocationRequest.create();
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        locationRequest.setInterval(10000);
        locationRequest.setFastestInterval(5000);

        // Iniciar componentes
        btnVisualizarMapa = findViewById(R.id.btnVisualizarMapa);
        radioVetorial = findViewById(R.id.radioVetorial);
        radioSatelite = findViewById(R.id.radioSatelite);
        radioHibrido = findViewById(R.id.radioHibrido);

        radioNorthUp = findViewById(R.id.radioNorthUp);
        radioCourseUp = findViewById(R.id.radioCourseUp);
        radioNenhuma = findViewById(R.id.radioNenhuma);

        radioPadrao = findViewById(R.id.radioPadrao);
        radioPersonalizado = findViewById(R.id.radioPersonalizado);

        switchTrafego = findViewById(R.id.switchTrafego);

        // Botão que salva as configurações e vai para o mapa
        btnVisualizarMapa.setOnClickListener(v -> {
            SharedPreferences prefs = getSharedPreferences("configMapa", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();

            // Tipo de mapa
            if (radioVetorial.isChecked()) editor.putInt("tipoMapa", GoogleMap.MAP_TYPE_NORMAL);
            else if (radioSatelite.isChecked()) editor.putInt("tipoMapa", GoogleMap.MAP_TYPE_SATELLITE);
            else if (radioHibrido.isChecked()) editor.putInt("tipoMapa", GoogleMap.MAP_TYPE_HYBRID);

            // Navegação
            if (radioNorthUp.isChecked()) editor.putString("navegacao", "north");
            else if (radioCourseUp.isChecked()) editor.putString("navegacao", "course");
            else if (radioNenhuma.isChecked()) editor.putString("navegacao", "nenhuma");

            // Ícone
            editor.putString("icone", radioPadrao.isChecked() ? "padrao" : "personalizado");

            // Tráfego
            editor.putBoolean("trafego", switchTrafego.isChecked());

            editor.apply();

            // Ir para a tela de mapa
            startActivity(new Intent(MainActivity.this, MapsActivity.class));
        });

        // Verifica permissão
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                    },
                    REQUEST_LOCATION_UPDATES);
        } else {
            startLocationUpdates();
        }
    }

    // Inicia a localização
    private void startLocationUpdates() {
        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                Location location = locationResult.getLastLocation();
                if (location != null) {
                    double latitude = location.getLatitude();
                    double longitude = location.getLongitude();
                    Toast.makeText(MainActivity.this,
                            "Localização atual: " + latitude + ", " + longitude,
                            Toast.LENGTH_SHORT).show();

                    // Se quiser salvar para MapsActivity:
                    SharedPreferences prefs = getSharedPreferences("configMapa", MODE_PRIVATE);
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putFloat("latitude", (float) latitude);
                    editor.putFloat("longitude", (float) longitude);
                    editor.apply();
                }
            }
        };

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            fusedLocationProviderClient.requestLocationUpdates(locationRequest, locationCallback, null);
        }
    }

    // Resultado da permissão
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_LOCATION_UPDATES) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startLocationUpdates();
            } else {
                Toast.makeText(this, "Permissão negada. Não será possível obter a localização.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
